import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: {
    colors: { ink: "#10172A", muted: "#68738A", line: "#E8EBF2", brand: "#6558E8", "brand-dark": "#5144D2", canvas: "#F7F8FC" },
    boxShadow: { soft: "0 12px 40px rgba(16,23,42,.07)" }
  }},
  plugins: []
} satisfies Config;