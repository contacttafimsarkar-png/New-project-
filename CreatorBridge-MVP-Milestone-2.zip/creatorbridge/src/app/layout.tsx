import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "CreatorBridge — Where Brands Meet Creators",
  description: "Discover creators, launch campaigns and manage brand collaborations in one place.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  openGraph: { title: "CreatorBridge", description: "Where Brands Meet Creators.", type: "website" }
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}