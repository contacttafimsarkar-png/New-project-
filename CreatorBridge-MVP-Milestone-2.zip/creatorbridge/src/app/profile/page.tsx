import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ProfileForm from "@/components/profile-form";
import BrandProfileForm from "@/components/brand-profile-form";
export default async function ProfilePage() {
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
 const {data:profile}=await supabase.from("profiles").select("*").eq("id",user.id).maybeSingle();
 if(profile?.role==="brand") {
  const {data:brand}=await supabase.from("brands").select("*").eq("user_id",user.id).maybeSingle();
  return <main className="min-h-screen bg-canvas px-5 py-12"><div className="mx-auto max-w-2xl"><a href="/dashboard" className="text-xl font-black">Creator<span className="text-brand">Bridge</span></a><div className="mt-8 rounded-3xl border border-line bg-white p-8"><h1 className="text-3xl font-black">Brand profile</h1><p className="mt-2 text-sm text-muted">Set up your company details before publishing campaigns.</p><BrandProfileForm profile={profile} brand={brand}/></div></div></main>;
 }
 const {data:creator}=await supabase.from("creator_profiles").select("*").eq("user_id",user.id).maybeSingle();
 return <main className="min-h-screen bg-canvas px-5 py-12"><div className="mx-auto max-w-2xl"><a href="/dashboard" className="text-xl font-black">Creator<span className="text-brand">Bridge</span></a><div className="mt-8 rounded-3xl border border-line bg-white p-8"><h1 className="text-3xl font-black">Your creator profile</h1><p className="mt-2 text-sm text-muted">Add the details brands need to work with you.</p><ProfileForm profile={profile} creator={creator} role={profile?.role||"creator"}/></div></div></main>;
}