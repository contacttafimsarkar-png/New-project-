import Link from "next/link";
import { ArrowUpRight, Menu, Sparkles } from "lucide-react";
export default function Navbar() {
  return <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur">
    <nav className="container flex h-[76px] items-center justify-between">
      <Link href="/" className="flex items-center gap-2 font-black tracking-tight text-xl"><span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-white"><Sparkles size={19}/></span>Creator<span className="text-brand">Bridge</span></Link>
      <div className="hidden items-center gap-8 text-sm font-semibold text-muted md:flex">
        <Link href="/creators" className="hover:text-ink">Discover Creators</Link><Link href="/campaigns" className="hover:text-ink">Browse Campaigns</Link><a href="/#how" className="hover:text-ink">How it works</a><a href="/#pricing" className="hover:text-ink">Pricing</a>
      </div>
      <div className="flex items-center gap-3"><Link href="/login" className="hidden text-sm font-bold md:block">Log in</Link><Link href="/signup" className="inline-flex items-center gap-2 rounded-xl bg-brand px-4 py-3 text-sm font-bold text-white shadow-soft hover:bg-brand-dark">Get started <ArrowUpRight size={16}/></Link></div>
    </nav>
  </header>;
}