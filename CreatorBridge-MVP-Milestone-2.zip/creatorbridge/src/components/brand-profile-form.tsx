"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
export default function BrandProfileForm({profile,brand}:{profile:any,brand:any}) {
 const [fullName,setFullName]=useState(profile?.full_name||"");
 const [company,setCompany]=useState(brand?.company_name||"");
 const [industry,setIndustry]=useState(brand?.industry||"");
 const [website,setWebsite]=useState(brand?.website||"");
 const [email,setEmail]=useState(brand?.business_email||"");
 const [city,setCity]=useState(brand?.city||"");
 const [description,setDescription]=useState(brand?.description||"");
 const [min,setMin]=useState(brand?.budget_min||""); const [max,setMax]=useState(brand?.budget_max||"");
 const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
 async function save(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");const db=createClient();const {data:{user}}=await db.auth.getUser();if(!user){setMessage("Please log in again.");setBusy(false);return;}
  const p=await db.from("profiles").update({full_name:fullName,country:"Bangladesh",city}).eq("id",user.id);if(p.error){setMessage(p.error.message);setBusy(false);return;}
  const b=await db.from("brands").upsert({user_id:user.id,company_name:company,industry,website:website||null,business_email:email||null,country:"Bangladesh",city,description,budget_min:min?Number(min):null,budget_max:max?Number(max):null},{onConflict:"user_id"});
  setMessage(b.error?b.error.message:"Brand profile saved.");setBusy(false);
 }
 const field="w-full rounded-xl border border-line px-4 py-3 outline-none focus:border-brand";
 return <form onSubmit={save} className="mt-7 space-y-4">
  {[{label:"Your name",value:fullName,set:setFullName,required:true},{label:"Company / brand name",value:company,set:setCompany,required:true},{label:"Industry",value:industry,set:setIndustry},{label:"Website",value:website,set:setWebsite},{label:"Business email",value:email,set:setEmail,type:"email"},{label:"City",value:city,set:setCity}].map(f=><label key={f.label} className="block"><span className="mb-2 block text-sm font-bold">{f.label}</span><input required={f.required} type={f.type||"text"} value={f.value} onChange={e=>f.set(e.target.value)} className={field}/></label>)}
  <label className="block"><span className="mb-2 block text-sm font-bold">Company description</span><textarea rows={4} value={description} onChange={e=>setDescription(e.target.value)} className={field}/></label>
  <div className="grid grid-cols-2 gap-3"><label><span className="mb-2 block text-sm font-bold">Minimum budget (৳)</span><input type="number" min="0" value={min} onChange={e=>setMin(e.target.value)} className={field}/></label><label><span className="mb-2 block text-sm font-bold">Maximum budget (৳)</span><input type="number" min="0" value={max} onChange={e=>setMax(e.target.value)} className={field}/></label></div>
  <button disabled={busy} className="w-full rounded-xl bg-brand px-5 py-4 font-bold text-white disabled:opacity-50">{busy?"Saving…":"Save brand profile"}</button>{message&&<p role="status" className="text-sm text-brand">{message}</p>}
 </form>;
}