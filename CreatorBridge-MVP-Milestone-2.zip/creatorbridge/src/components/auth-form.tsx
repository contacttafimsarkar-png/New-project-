"use client";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function AuthForm({mode}:{mode:"login"|"signup"}) {
 const router=useRouter(), params=useSearchParams();
 const [role,setRole]=useState(params.get("role")==="brand"?"brand":"creator");
 const [name,setName]=useState(""), [email,setEmail]=useState(""), [password,setPassword]=useState("");
 const [error,setError]=useState(""), [busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent) {
  e.preventDefault(); setError(""); setBusy(true);
  try {
   const supabase=createClient();
   if(mode==="signup") {
    const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,role}}});
    if(error) throw error;
    if(data.user) {
     const {error:profileError}=await supabase.from("profiles").upsert({id:data.user.id,full_name:name,role});
     if(profileError) throw profileError;
    }
    setError("Account created. Check your email if confirmation is enabled, then log in.");
   } else {
    const {error}=await supabase.auth.signInWithPassword({email,password});
    if(error) throw error;
    router.push("/dashboard"); router.refresh();
   }
  } catch(err) { setError(err instanceof Error?err.message:"Something went wrong."); }
  finally {setBusy(false);}
 }
 return <form onSubmit={submit} className="mt-7 space-y-4">
  {mode==="signup"&&<><div><label className="mb-2 block text-sm font-bold">I am joining as</label><div className="grid grid-cols-2 gap-2">{["creator","brand"].map(r=><button type="button" key={r} onClick={()=>setRole(r)} className={`rounded-xl border px-4 py-3 text-sm font-bold capitalize ${role===r?"border-brand bg-indigo-50 text-brand":"border-line"}`}>{r}</button>)}</div></div><div><label className="mb-2 block text-sm font-bold">Full name</label><input required value={name} onChange={e=>setName(e.target.value)} className="w-full rounded-xl border border-line px-4 py-3 outline-none focus:border-brand"/></div></>}
  <div><label className="mb-2 block text-sm font-bold">Email address</label><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} className="w-full rounded-xl border border-line px-4 py-3 outline-none focus:border-brand"/></div>
  <div><label className="mb-2 block text-sm font-bold">Password</label><input required minLength={8} type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full rounded-xl border border-line px-4 py-3 outline-none focus:border-brand"/><p className="mt-1 text-xs text-muted">Use at least 8 characters.</p></div>
  {error&&<p role="status" className="rounded-xl bg-indigo-50 p-3 text-sm text-indigo-900">{error}</p>}
  <button disabled={busy} className="w-full rounded-xl bg-brand px-5 py-4 font-bold text-white disabled:opacity-50">{busy?"Please wait…":mode==="signup"?"Create account":"Log in"}</button>
  <p className="text-center text-sm text-muted">{mode==="signup"?"Already have an account?":"New to CreatorBridge?"} <Link className="font-bold text-brand" href={mode==="signup"?"/login":"/signup"}>{mode==="signup"?"Log in":"Create account"}</Link></p>
 </form>;
}