import Link from "next/link";
export default function Footer() {
 return <footer className="bg-ink py-14 text-white"><div className="container grid gap-10 md:grid-cols-4">
  <div className="md:col-span-2"><div className="text-xl font-black">Creator<span className="text-indigo-300">Bridge</span></div><p className="mt-3 max-w-sm text-sm leading-6 text-slate-400">A better way for brands and creators to build meaningful partnerships. Where Brands Meet Creators.</p></div>
  <div><p className="mb-4 font-bold">Explore</p><div className="grid gap-3 text-sm text-slate-400"><Link href="/creators">Discover creators</Link><Link href="/campaigns">Browse campaigns</Link><Link href="/signup">Join CreatorBridge</Link></div></div>
  <div><p className="mb-4 font-bold">Company</p><div className="grid gap-3 text-sm text-slate-400"><Link href="/#how">How it works</Link><Link href="/terms">Terms</Link><Link href="/privacy">Privacy</Link><a href="mailto:hello@creatorbridge.example">Contact support</a></div></div>
 </div><div className="container mt-12 border-t border-white/10 pt-6 text-xs text-slate-500">© {new Date().getFullYear()} CreatorBridge. Built for better collaborations.</div></footer>;
}