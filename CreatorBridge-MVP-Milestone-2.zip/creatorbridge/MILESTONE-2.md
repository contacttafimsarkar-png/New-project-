# CreatorBridge — Milestone 2

## Delivered

- Brand profile onboarding and editing (Bangladesh / BDT defaults).
- Campaign publishing form with description, product/service, target audience, platform preferences, niches, location, budget, deliverables, deadlines and instructions.
- Public campaign discovery and detailed campaign pages.
- Creator application submission with proposal and proposed rate.
- Creator application history.
- Brand-owned campaign list and applicant review (shortlist / accept / reject).
- Supabase migration `0002_marketplace_workflows.sql` adds published-campaign application constraints, a narrowly scoped brand review RPC, brand-role ownership enforcement and removes creator-side application status mutation.

## Apply migrations

Run in Supabase SQL Editor in this order:

1. `supabase/migrations/0001_initial_schema.sql`
2. `supabase/migrations/0002_marketplace_workflows.sql`

## Verification status

Source files and SQL migration were generated and the ZIP archive was checked for integrity. A full Next.js production build and live Supabase integration test could not be run in this environment because package installation timed out and no Supabase project credentials were supplied.

## Remaining before public launch

- Install dependencies and run `npm run build`.
- Test signup/login and all role-based workflows against a real Supabase staging project.
- Implement brand public directory data without exposing business contact fields.
- Add campaign edit/pause/resume UI and creator invitation workflow.
- Add collaboration negotiation, messaging, deliverables and reviews.
- Add secure admin claims, moderation and dispute workflows.
- Integrate approved payment providers with signed webhook verification and reconciliation.
- Complete automated tests, security review, legal pages, backups and monitoring.
