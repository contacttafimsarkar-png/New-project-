-- Marketplace workflow hardening and brand application review.
-- Apply after 0001_initial_schema.sql.

-- Replace the broad creator application insert policy with a published-campaign-only policy.
drop policy if exists "creator applies" on public.applications;
create policy "creator applies to published campaigns" on public.applications
for insert with check (
 exists(select 1 from public.creator_profiles c join public.profiles p on p.id=c.user_id
        where c.id=creator_id and c.user_id=auth.uid() and p.role='creator')
 and exists(select 1 from public.campaigns cp where cp.id=campaign_id and cp.status='published'
            and (cp.application_deadline is null or cp.application_deadline >= current_date))
);

-- Brand review is performed through a narrow RPC so brands cannot alter the creator's proposal or rate.
create or replace function public.review_campaign_application(p_application_id uuid, p_status public.application_status)
returns void language plpgsql security definer set search_path=public as $$
declare owns_campaign boolean;
begin
 if p_status not in ('accepted','rejected','shortlisted') then
   raise exception 'Unsupported review status';
 end if;
 select exists(
   select 1 from public.applications a
   join public.campaigns cp on cp.id=a.campaign_id
   join public.brands b on b.id=cp.brand_id
   where a.id=p_application_id and b.user_id=auth.uid()
 ) into owns_campaign;
 if not owns_campaign then raise exception 'Not authorized to review this application'; end if;
 update public.applications set status=p_status where id=p_application_id;
end; $$;
revoke all on function public.review_campaign_application(uuid,public.application_status) from public;
grant execute on function public.review_campaign_application(uuid,public.application_status) to authenticated;

-- Add policy for brand owners to read campaign applicants (existing select policy already scopes both sides).
-- Creator can read and update only their own proposal/application; brands use the RPC above.

-- Keep role assignment protected. The signup trigger is the only public role creation path.

-- Ensure only accounts whose immutable profile role is 'brand' can own brand records/campaigns.
drop policy if exists "brand owner manages brand" on public.brands;
create policy "brand accounts manage own brand" on public.brands
for all using (
 user_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='brand')
) with check (
 user_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='brand')
);

drop policy if exists "brand manages campaigns" on public.campaigns;
create policy "brand accounts manage own campaigns" on public.campaigns
for all using (
 exists(select 1 from public.brands b join public.profiles p on p.id=b.user_id
        where b.id=brand_id and b.user_id=auth.uid() and p.role='brand')
) with check (
 exists(select 1 from public.brands b join public.profiles p on p.id=b.user_id
        where b.id=brand_id and b.user_id=auth.uid() and p.role='brand')
);

-- Creators cannot edit application status or change their submitted proposal after sending it.
-- Brand status changes are handled only by review_campaign_application().
drop policy if exists "creator updates own application" on public.applications;
