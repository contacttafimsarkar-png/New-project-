-- CreatorBridge initial schema. Run in Supabase SQL editor or via Supabase CLI.
create extension if not exists pgcrypto;

create type public.user_role as enum ('creator','brand','admin');
create type public.campaign_status as enum ('draft','published','paused','completed','cancelled');
create type public.application_status as enum ('pending','shortlisted','accepted','rejected','withdrawn');
create type public.collaboration_status as enum ('proposed','active','submitted','revision_requested','approved','completed','cancelled');
create type public.payment_status as enum ('created','pending','succeeded','failed','refunded','paid_out');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 role public.user_role not null default 'creator',
 full_name text not null default '',
 avatar_url text,
 country text,
 city text,
 bio text,
 is_verified boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.creator_profiles (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null unique references public.profiles(id) on delete cascade,
 username text not null unique,
 niche text,
 starting_price numeric(12,2) check (starting_price is null or starting_price >= 0),
 average_views bigint check (average_views is null or average_views >= 0),
 engagement_rate numeric(5,2) check (engagement_rate is null or engagement_rate between 0 and 100),
 language text,
 country text,
 is_public boolean not null default false,
 metrics_verified_at timestamptz,
 created_at timestamptz not null default now()
);

create table public.brands (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null unique references public.profiles(id) on delete cascade,
 company_name text not null,
 logo_url text,
 industry text,
 website text,
 business_email text,
 country text,
 city text,
 description text,
 budget_min numeric(12,2),
 budget_max numeric(12,2),
 created_at timestamptz not null default now()
);

create table public.social_accounts (
 id uuid primary key default gen_random_uuid(),
 creator_id uuid not null references public.creator_profiles(id) on delete cascade,
 platform text not null check (platform in ('youtube','instagram','tiktok','facebook','twitch','blog','podcast','other')),
 profile_url text not null,
 handle text,
 follower_count bigint check (follower_count is null or follower_count >= 0),
 average_views bigint check (average_views is null or average_views >= 0),
 metrics_source text not null default 'self_reported',
 verified_at timestamptz,
 created_at timestamptz not null default now()
);

create table public.campaigns (
 id uuid primary key default gen_random_uuid(),
 brand_id uuid not null references public.brands(id) on delete cascade,
 title text not null,
 description text not null,
 product_service text,
 target_audience text,
 preferred_platforms text[] not null default '{}',
 creator_niches text[] not null default '{}',
 location text,
 budget_total numeric(12,2) not null check (budget_total >= 0),
 creator_budget numeric(12,2) check (creator_budget is null or creator_budget >= 0),
 currency char(3) not null default 'BDT',
 deliverables jsonb not null default '[]',
 deadline date,
 application_deadline date,
 special_instructions text,
 status public.campaign_status not null default 'draft',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.applications (
 id uuid primary key default gen_random_uuid(),
 campaign_id uuid not null references public.campaigns(id) on delete cascade,
 creator_id uuid not null references public.creator_profiles(id) on delete cascade,
 proposal text not null,
 proposed_rate numeric(12,2) not null check (proposed_rate >= 0),
 status public.application_status not null default 'pending',
 created_at timestamptz not null default now(),
 unique(campaign_id,creator_id)
);

create table public.invitations (
 id uuid primary key default gen_random_uuid(),
 campaign_id uuid not null references public.campaigns(id) on delete cascade,
 creator_id uuid not null references public.creator_profiles(id) on delete cascade,
 message text,
 proposed_rate numeric(12,2),
 status text not null default 'pending' check (status in ('pending','accepted','declined','expired')),
 created_at timestamptz not null default now(),
 unique(campaign_id,creator_id)
);

create table public.collaborations (
 id uuid primary key default gen_random_uuid(),
 campaign_id uuid not null references public.campaigns(id),
 brand_id uuid not null references public.brands(id),
 creator_id uuid not null references public.creator_profiles(id),
 agreed_amount numeric(12,2) not null check (agreed_amount >= 0),
 currency char(3) not null default 'BDT',
 status public.collaboration_status not null default 'proposed',
 due_date date,
 created_at timestamptz not null default now()
);

create table public.messages (
 id uuid primary key default gen_random_uuid(),
 collaboration_id uuid not null references public.collaborations(id) on delete cascade,
 sender_id uuid not null references public.profiles(id),
 body text not null check (char_length(body) between 1 and 10000),
 attachment_path text,
 created_at timestamptz not null default now()
);

create table public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 title text not null,
 body text,
 read_at timestamptz,
 created_at timestamptz not null default now()
);

create table public.deliverables (
 id uuid primary key default gen_random_uuid(),
 collaboration_id uuid not null references public.collaborations(id) on delete cascade,
 title text not null,
 description text,
 file_path text,
 external_url text,
 status text not null default 'submitted' check (status in ('submitted','approved','revision_requested')),
 feedback text,
 submitted_at timestamptz not null default now(),
 reviewed_at timestamptz
);

create table public.payments (
 id uuid primary key default gen_random_uuid(),
 collaboration_id uuid not null references public.collaborations(id),
 payer_id uuid not null references public.profiles(id),
 payee_id uuid not null references public.profiles(id),
 gross_amount numeric(12,2) not null check (gross_amount >= 0),
 commission_amount numeric(12,2) not null check (commission_amount >= 0),
 currency char(3) not null default 'BDT',
 provider text,
 provider_reference text unique,
 status public.payment_status not null default 'created',
 sandbox boolean not null default true,
 created_at timestamptz not null default now()
);

create table public.reviews (
 id uuid primary key default gen_random_uuid(),
 collaboration_id uuid not null references public.collaborations(id),
 reviewer_id uuid not null references public.profiles(id),
 reviewee_id uuid not null references public.profiles(id),
 rating smallint not null check (rating between 1 and 5),
 comment text,
 created_at timestamptz not null default now(),
 unique(collaboration_id,reviewer_id)
);

create table public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references public.profiles(id),
 reported_user_id uuid references public.profiles(id),
 campaign_id uuid references public.campaigns(id),
 reason text not null,
 details text,
 status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
 created_at timestamptz not null default now()
);

create table public.platform_settings (
 key text primary key,
 value jsonb not null,
 updated_at timestamptz not null default now()
);
insert into public.platform_settings(key,value) values
 ('commission_rate','0.10'::jsonb),
 ('default_currency','"BDT"'::jsonb)
 on conflict (key) do nothing;

-- Profile creation trigger. Role comes from signup metadata but admin is never self-assignable.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare chosen_role public.user_role;
begin
 chosen_role := case when new.raw_user_meta_data->>'role' = 'brand' then 'brand'::public.user_role else 'creator'::public.user_role end;
 insert into public.profiles(id,role,full_name) values(new.id,chosen_role,coalesce(new.raw_user_meta_data->>'full_name',''));
 return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Prevent self-service privilege escalation through profile updates.
create or replace function public.prevent_role_escalation()
returns trigger language plpgsql as $$
begin
 if new.role is distinct from old.role and coalesce(auth.role(),'') <> 'service_role' then
   raise exception 'Role changes require a trusted administrative process';
 end if;
 return new;
end; $$;
create trigger protect_profile_role before update of role on public.profiles
for each row execute procedure public.prevent_role_escalation();

-- RLS is enabled on all application tables.
alter table public.profiles enable row level security;
alter table public.creator_profiles enable row level security;
alter table public.brands enable row level security;
alter table public.social_accounts enable row level security;
alter table public.campaigns enable row level security;
alter table public.applications enable row level security;
alter table public.invitations enable row level security;
alter table public.collaborations enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.deliverables enable row level security;
alter table public.payments enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;
alter table public.platform_settings enable row level security;

-- Users can read public profile basics and update only their own profile.
create policy "profiles are readable" on public.profiles for select using (true);
create policy "users update own profile" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);
create policy "public creator profiles" on public.creator_profiles for select using (is_public or user_id=auth.uid());
create policy "creator manages own profile" on public.creator_profiles for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "brands readable by owner" on public.brands for select using (user_id=auth.uid());
create policy "brand owner manages brand" on public.brands for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "social accounts visible with public creator" on public.social_accounts for select using (exists(select 1 from public.creator_profiles c where c.id=creator_id and (c.is_public or c.user_id=auth.uid())));
create policy "creator manages social accounts" on public.social_accounts for all using (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid())) with check (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "published campaigns visible" on public.campaigns for select using (status='published' or exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid()));
create policy "brand manages campaigns" on public.campaigns for all using (exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid())) with check (exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid()));
create policy "creator sees own applications" on public.applications for select using (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()) or exists(select 1 from public.campaigns cp join public.brands b on b.id=cp.brand_id where cp.id=campaign_id and b.user_id=auth.uid()));
create policy "creator applies" on public.applications for insert with check (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "creator updates own application" on public.applications for update using (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid())) with check (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "participants see invitations" on public.invitations for select using (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()) or exists(select 1 from public.campaigns cp join public.brands b on b.id=cp.brand_id where cp.id=campaign_id and b.user_id=auth.uid()));
create policy "brand creates invitations" on public.invitations for insert with check (exists(select 1 from public.campaigns cp join public.brands b on b.id=cp.brand_id where cp.id=campaign_id and b.user_id=auth.uid()));
create policy "invitee updates invitation" on public.invitations for update using (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid())) with check (exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "collaboration participants read" on public.collaborations for select using (exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "brand creates collaboration" on public.collaborations for insert with check (exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid()));
create policy "participants update collaboration" on public.collaborations for update using (exists(select 1 from public.brands b where b.id=brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=creator_id and c.user_id=auth.uid()));
create policy "participants read messages" on public.messages for select using (exists(select 1 from public.collaborations co where co.id=collaboration_id and (exists(select 1 from public.brands b where b.id=co.brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=co.creator_id and c.user_id=auth.uid()))));
create policy "participants send messages" on public.messages for insert with check (sender_id=auth.uid() and exists(select 1 from public.collaborations co where co.id=collaboration_id and (exists(select 1 from public.brands b where b.id=co.brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=co.creator_id and c.user_id=auth.uid()))));
create policy "own notifications" on public.notifications for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "collab participants deliverables" on public.deliverables for select using (exists(select 1 from public.collaborations co where co.id=collaboration_id and (exists(select 1 from public.brands b where b.id=co.brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=co.creator_id and c.user_id=auth.uid()))));
create policy "creator submits deliverables" on public.deliverables for insert with check (exists(select 1 from public.collaborations co join public.creator_profiles c on c.id=co.creator_id where co.id=collaboration_id and c.user_id=auth.uid()));
create policy "participants update deliverables" on public.deliverables for update using (exists(select 1 from public.collaborations co where co.id=collaboration_id and (exists(select 1 from public.brands b where b.id=co.brand_id and b.user_id=auth.uid()) or exists(select 1 from public.creator_profiles c where c.id=co.creator_id and c.user_id=auth.uid()))));
create policy "payment participants read" on public.payments for select using (payer_id=auth.uid() or payee_id=auth.uid());
create policy "reviews visible" on public.reviews for select using (true);
create policy "participants write reviews" on public.reviews for insert with check (reviewer_id=auth.uid());
create policy "users create reports" on public.reports for insert with check (reporter_id=auth.uid());
create policy "reporters read own reports" on public.reports for select using (reporter_id=auth.uid());
create policy "settings readable" on public.platform_settings for select using (true);

-- Admin operations must use a server-side authorization path and a trusted admin claim.
-- Do not grant admin by editing user metadata from the client.
