# CreatorBridge

A Bangladesh-first creator/brand collaboration marketplace starter built with Next.js, TypeScript, Tailwind CSS and Supabase.

## Included in this MVP foundation

- Premium responsive marketing homepage and navigation
- Creator/brand signup and email/password login
- Authenticated dashboard with database-backed counts
- Creator profile editing and public creator discovery
- Published campaign discovery
- Brand profile onboarding and editing
- Campaign publishing form with BDT budgets, platform preferences and deadlines
- Campaign detail pages and creator application submission
- Brand applicant review (accept / reject / shortlist)
- Creator application history
- Relational PostgreSQL schema for marketplace workflows
- Row-level security policies for core data access
- BDT-first money fields and configurable commission setting
- Sandbox-first payment record architecture (no fake payment success)

## Important status

This is a working application foundation, not a fully launched marketplace. Messaging UI, campaign creation/application forms, negotiation, deliverable review, admin operations, provider payment integrations, automated tests, legal review and production monitoring still need implementation and verification. Do not accept real money until a payment provider is approved, credentials are configured, webhook signatures are verified server-side, and the settlement model has been legally reviewed.

## Requirements

- Node.js 20+
- A Supabase project
- npm

## Local setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env.local` and set:

   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_SITE_URL`

   Never put the Supabase service-role key in a `NEXT_PUBLIC_` variable or browser code.

3. In Supabase SQL Editor, run `supabase/migrations/0001_initial_schema.sql`, then `supabase/migrations/0002_marketplace_workflows.sql`.

4. In Supabase Authentication settings, configure your site URL and allowed redirect URLs, for example `http://localhost:3000`.

5. Run:

   ```bash
   npm run dev
   ```

6. Visit `http://localhost:3000`.

## Supabase setup notes

- Enable email authentication.
- For early testing, decide whether email confirmation is enabled. For public launch, keep email confirmation enabled and configure SMTP.
- Create storage buckets for `avatars`, `portfolios`, `deliverables`, and `message-attachments`. Keep private files private and use short-lived signed URLs.
- Add storage policies before accepting uploads.
- Set the initial admin role only through a trusted server-side process or Supabase custom claims. Never allow users to set their own `admin` role.
- Review every RLS policy with at least two test users of each role before launch.

## Deployment to Vercel

1. Push the project to a private Git repository.
2. Import it into Vercel.
3. Add the same public Supabase environment variables in Vercel.
4. Set `NEXT_PUBLIC_SITE_URL` to the production URL.
5. Deploy, then add the custom domain in Vercel and configure the DNS records it provides.
6. Add the final domain and auth callback URLs in Supabase.
7. Run a production smoke test for signup, login, creator profile publishing, campaign visibility and sign-out.

## Payment integration plan

Implement each provider behind a server-only adapter. The browser must never be trusted to set payment status. A verified provider webhook should update the payment ledger idempotently. Until merchant credentials and approvals are available, `PAYMENT_MODE=sandbox` and `payments.sandbox=true` must remain in use. Do not describe the feature as escrow unless the provider and applicable law support escrow.

## Pre-launch checklist

- [ ] Replace placeholder terms and privacy pages with reviewed legal documents.
- [ ] Configure SMTP, email verification and password reset.
- [ ] Add CAPTCHA and rate limiting to auth and public forms.
- [ ] Complete brand onboarding and campaign CRUD.
- [ ] Complete creator applications, invitations and collaboration workflow.
- [ ] Implement realtime conversations with participant-only access.
- [ ] Implement private file storage and upload scanning/size limits.
- [ ] Add admin custom claims and server-side admin routes.
- [ ] Add payment provider, signed webhook verification and reconciliation.
- [ ] Add audit logs, error monitoring, backups and restore drills.
- [ ] Add automated unit, integration, RLS and end-to-end tests.
- [ ] Conduct security review and Bangladesh legal/tax/payment review.
- [ ] Verify mobile, keyboard and screen-reader behavior.
- [ ] Configure sitemap, robots.txt, analytics consent and production SEO.

## Known next implementation steps

The next development milestone should add:
1. Brand onboarding and brand profile editing.
2. Campaign creation/edit/pause with brand ownership checks.
3. Creator application and brand review workflows.
4. Collaboration messaging and deliverables.
5. Admin moderation and verified provider payment integration.
